THE ART OF SURRENDER — COVER ART
Blair Purvis · Prahran Publishing, Melbourne · published 15 October 2026
blairpurvis.com/books/the-art-of-surrender/

For press, review, festival and bookseller use in connection with the book.
Please reproduce the cover whole — no cropping, overprinting or recolouring.

the-art-of-surrender-cover-print.jpg   3600 × 5400 px (6 × 9 in at 600 ppi), sRGB
the-art-of-surrender-cover-web.jpg     1200 × 1800 px, sRGB

Contact: me@blairpurvis.com
