BLAIR PURVIS — AUTHOR PORTRAITS
blairpurvis.com/press/

Photograph: Julian Dolman — headshotphotographer.com.au
Please credit the photographer wherever the image appears.

For press, review, festival and bookseller use in connection with
Blair Purvis and his books. Crop as you need; please don't otherwise
alter or retouch.

print/  high resolution, 3600 px on the long edge (12 in at 300 ppi)
web/    1000 px on the long edge, for screens and social media

Files
  blair-purvis-030.jpg — colour, three-quarter, dark background
  blair-purvis-030-mono.jpg — black and white, three-quarter, dark background
  blair-purvis-138.jpg — colour, outdoors, tan jacket

Colour files are sRGB; the black-and-white file is greyscale.
Contact: me@blairpurvis.com
